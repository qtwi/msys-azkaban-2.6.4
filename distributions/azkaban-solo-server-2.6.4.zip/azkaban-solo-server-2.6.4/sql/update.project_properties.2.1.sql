ALTER TABLE project_properties MODIFY name VARCHAR(255);


